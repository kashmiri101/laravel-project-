<?php echo $__env->make("frontend.layouts.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<?php echo $__env->yieldContent("main-container"); ?>;


<?php echo $__env->make("frontend.layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\company\resources\views/frontend/layouts/main.blade.php ENDPATH**/ ?>